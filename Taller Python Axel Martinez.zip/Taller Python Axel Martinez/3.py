
palabra = input("escriba aqui: ")
print("")

orden = 0
for i in palabra : 
    if orden % 2 == 0: 
        print (i)
    orden = orden + 1
    
