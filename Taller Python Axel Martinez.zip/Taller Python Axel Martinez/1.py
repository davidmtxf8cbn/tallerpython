
n1 = int(input("ingrese el numero: "))
n2 = int(input("ingrese el segundo numero: "))

producto = n1 * n2
def punto1():
    if producto > 1000:
        return producto

print(punto1())

print("la suma de los valores ingresados es: ",(n1+n2))
