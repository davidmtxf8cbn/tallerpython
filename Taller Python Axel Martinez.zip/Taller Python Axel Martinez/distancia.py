import math

x2 = float(int("ingrese x2:"))
x1 = float(int("ingrese x1:"))
y2 = float(int("ingrese y2:"))
y1 = float(int("ingrese y1:"))

d = math.sqrt(math.pow((x2-x1),2)+math.pow((y2-y1),2))

print("distancia: ",d)
