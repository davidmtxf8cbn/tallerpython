
import math
radio = float(input("ingrese el radio del circulo: "))

area = math.pi * (radio*radio)

print ("el area es: ",area)
